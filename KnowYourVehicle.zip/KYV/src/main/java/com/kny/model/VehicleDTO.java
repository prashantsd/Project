package com.kny.model;

import java.time.LocalDate;


import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.kny.entity.PoliceStation;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleDTO {
	
	private int id;
	
	@NotNull(message = "vehicleNo cannot be null")
	@NotBlank(message = "vehicleNo is required")
	@Size(max = 12,message = "Maximum 12 character allowed")
	@Size(min = 10,message = "Minimum 10 values rewuired")
	private String vehicleNo;
	
	@NotNull(message = "company cannot be null")
	@NotBlank(message = "company is required")
	@Size(max = 20,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String company;
	
	@NotNull(message = "vehicleType cannot be null")
	@NotBlank(message = "vehicleType is required")
	@Size(max = 20,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String vehicleType;
	
	@NotNull(message = "address cannot be null")
	@NotBlank(message = "address is required")
	@Size(max = 40,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String address;

	
	private LocalDate dof;
	
	
	@ManyToOne
	private PoliceStation station;
}
