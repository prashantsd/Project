package com.kny.model;

import java.util.List;


import com.kny.entity.Vehicle;

import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PoliceStationDTO extends UserDTO{

	
	@NotNull(message = "Station name cannot be null")
	@NotBlank(message = "Station name is required")
	@Size(max = 20,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String stationName;
	
	@NotNull(message = "City cannot be null")
	@NotBlank(message = "City is required")
	@Size(max = 20,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String city;
	
	@NotNull(message = "Address cannot be null")
	@NotBlank(message = "Address is required")
	@Size(max = 40,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String address;
	
	@NotNull(message = "Contact cannot be null")
	@NotBlank(message = "Contact is required")
	@Size(max = 20,message = "Maximum 20 character allowed")
	@Size(min = 2,message = "Minimum 2 values rewuired")
	private String contact;
	
	@NotNull(message = "Pin Code cannot be null")
	@NotBlank(message = "Pin Code is required")
	@Size(max = 6,message = "Maximum 6 character allowed")
	private String pinCode;
	
	@OneToMany
	private List<Vehicle> vehicles;
	
}
