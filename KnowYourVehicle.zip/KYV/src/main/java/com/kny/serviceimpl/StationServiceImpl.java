package com.kny.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kny.entity.PoliceStation;
import com.kny.exception.ResourceNotFoundException;
import com.kny.model.PoliceStationDTO;
import com.kny.repository.StationRepository;
import com.kny.service.StationService;
import com.kny.utils.StationConverter;

@Service
public class StationServiceImpl implements StationService{

	@Autowired
	StationConverter sConverter;
	
	@Autowired
	StationRepository stationRepository;
	
	@Override
	public PoliceStationDTO saveStation(PoliceStation pStation) {
		stationRepository.save(pStation);
		return sConverter.converterToStationDTO(pStation);
	}

	@Override
	public List<PoliceStationDTO> getAllStations() {
		List<PoliceStation> stations = stationRepository.findAll();
		
		// convert all policeStation entity into policeStationDTO
		List<PoliceStationDTO> psDtos = new ArrayList<>();
		for(PoliceStation p : stations)
		{
			psDtos.add(sConverter.converterToStationDTO(p));
		}
		return psDtos;
	}

	@Override
	public PoliceStationDTO updateStationById(int stationId, PoliceStation policeStation) {
		PoliceStation existStation = stationRepository.findById(stationId).get();
		
		//updating the existing Police Station details with new details
		existStation.setStationName(policeStation.getStationName());
		existStation.setCity(policeStation.getCity());
		existStation.setAddress(policeStation.getAddress());
		existStation.setContact(policeStation.getContact());
		existStation.setPinCode(policeStation.getPinCode());
		existStation.setUserName(policeStation.getUserName());
		existStation.setPassword(policeStation.getPassword());
		
		stationRepository.save(existStation);
		
		return sConverter.converterToStationDTO(existStation);
	}

	@Override
	public void deleteStationById(int stationId) {
		
		Optional<PoliceStation> station = stationRepository.findById(stationId);
		
		if(station.isPresent())
		{
			stationRepository.deleteById(stationId);
		}else {
			throw new ResourceNotFoundException("Resource", "Id", stationId);
		}
		
	}

	@Override
	public PoliceStationDTO getStationById(int id) {
		
		
		PoliceStation station = stationRepository.findById(id).get();
		
		if(station == null)
		{
			throw new ResourceNotFoundException("Police Station","Id",id);
		}
		
		return sConverter.converterToStationDTO(station);
	}
	
	
	

}
