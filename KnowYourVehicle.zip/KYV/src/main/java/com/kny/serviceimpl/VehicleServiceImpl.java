package com.kny.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kny.entity.PoliceStation;
import com.kny.entity.Vehicle;
import com.kny.exception.ResourceNotFoundException;
import com.kny.exception.VehicleNoAlreadyExist;
import com.kny.model.VehicleDTO;
import com.kny.repository.StationRepository;
import com.kny.repository.VehicleRepository;
import com.kny.service.VehicleService;
import com.kny.utils.VehicleConverter;

@Service
public class VehicleServiceImpl implements VehicleService{

	
	@Autowired
	VehicleConverter vConverter;
	
	@Autowired
	StationRepository sRepository;
	
	@Autowired
	VehicleRepository vRepository;
	
	@Override
	public VehicleDTO addVehicle(Vehicle vehicle) {
		
		List<Vehicle> vehicles = vRepository.findAll();
		
		for(Vehicle v : vehicles)
		{
			if(v.getVehicleNo().equalsIgnoreCase(vehicle.getVehicleNo()))
			{
				throw new VehicleNoAlreadyExist("Vehicle Already exist.");
			}
		}
		
		vRepository.save(vehicle);
		
		return vConverter.converterToVehicleDTO(vehicle);
	}

	@Override
	public VehicleDTO getVehicleDetailsByNo(String vehicleNo) {
		
	
		Vehicle vehicle = vRepository.findByVehicleNo(vehicleNo);
		
		if(vehicle == null)
		{
			throw new ResourceNotFoundException("Vehicle","VehicleNo",vehicleNo);
		}
		
		return vConverter.converterToVehicleDTO(vehicle);
	}

	@Override
	public VehicleDTO updateVehicleById(int id,Vehicle vehicle){
		Vehicle exitVehicle = vRepository.findById(id).get();
		
		//updating the existing vehicle details with new details 
		exitVehicle.setVehicleNo(vehicle.getVehicleNo());
		exitVehicle.setCompany(vehicle.getCompany());
		exitVehicle.setAddress(vehicle.getAddress());
		exitVehicle.setDof(vehicle.getDof());
		exitVehicle.setVehicleType(vehicle.getVehicleType());
		
		
		vRepository.save(exitVehicle);
		return vConverter.converterToVehicleDTO(exitVehicle);
	}

	@Override
	public void deleteVehicleDetailsById(int id) {
		
		Optional<Vehicle> vehicle = vRepository.findById(id);
		
		if(vehicle.isPresent())
		{
			vRepository.deleteById(id);
		}
		else
		{
			throw new ResourceNotFoundException("Resource", "Id", id);
		}
		
		
		
	}

	@Override
	public VehicleDTO assignVehicleToStation(int vehicleId, int stationId) {
		
		
		
		Vehicle vehicle = vRepository.findById(vehicleId).orElseThrow(()->
		new ResourceNotFoundException("Vehicle","Id", vehicleId));
		
		PoliceStation  pStation = sRepository.findById(stationId).orElseThrow(()->
		new ResourceNotFoundException("Police Station","Id", stationId));
		
		
				
		vehicle.setStation(pStation);
		
		vRepository.save(vehicle);
		sRepository.save(pStation);
		
		return vConverter.converterToVehicleDTO(vehicle);
	}

}
