package com.kny.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.kny.entity.PoliceStation;



public interface StationRepository extends JpaRepository<PoliceStation, Integer> {
	
	
	

}
