package com.kny.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.kny.entity.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer>{

	Vehicle findByVehicleNo(String vehicleNo);

	
}
