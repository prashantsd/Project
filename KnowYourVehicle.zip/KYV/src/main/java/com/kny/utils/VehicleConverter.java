package com.kny.utils;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.kny.entity.Vehicle;
import com.kny.model.VehicleDTO;

@Component
public class VehicleConverter {

				// convert Vehicle entity into VehicleDTO
				public VehicleDTO converterToVehicleDTO(Vehicle vehicle)
				{
					VehicleDTO pDto = new VehicleDTO();
					if(vehicle != null)
					{
						BeanUtils.copyProperties(vehicle, pDto);
					}
					return pDto;
				}
				
				// convert VehicleDTO to Vehicle entity
				public Vehicle converToVehicleEntity(VehicleDTO pDto)
				{
					Vehicle vehicle = new Vehicle();
					if(pDto != null)
					{
						BeanUtils.copyProperties(pDto, vehicle);
					}
					return vehicle;
				}

	
}
