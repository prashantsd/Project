package com.kny.utils;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.kny.entity.PoliceStation;
import com.kny.model.PoliceStationDTO;

@Component
public class StationConverter {
	
	// convert PoliceStation entity into PoliceStationDTO
			public PoliceStationDTO converterToStationDTO(PoliceStation pStation)
			{
				PoliceStationDTO pDto = new PoliceStationDTO();
				if(pStation != null)
				{
					BeanUtils.copyProperties(pStation, pDto);
				}
				return pDto;
			}
			
			// convert PoliceStationDTO to PoliceStation entity
			public PoliceStation converToStationEntity(PoliceStationDTO pDto)
			{
				PoliceStation pStation = new PoliceStation();
				if(pDto != null)
				{
					BeanUtils.copyProperties(pDto, pStation);
				}
				return pStation;
			}

}
