package com.kny.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kny.entity.PoliceStation;
import com.kny.model.PoliceStationDTO;
import com.kny.service.StationService;
import com.kny.utils.StationConverter;

@RestController
public class StationController {
	
	@Autowired
	StationConverter sConverter;

	@Autowired
	StationService stationService;
	
//	build save station using REST API
	@PostMapping("/saveStation")
	public PoliceStationDTO saveStation(@Valid @RequestBody PoliceStationDTO stationDTO)
	{
		PoliceStation pStation = sConverter.converToStationEntity(stationDTO);
		return stationService.saveStation(pStation);
	}
	
	
	// build get all Stations details using REST API
	@GetMapping("/getAllStations")
	public List<PoliceStationDTO> getAllStation()
	{
		return stationService.getAllStations();
	}
	
	
	// build Police Station details using id REST API
	@PutMapping("/updateStation/{stationId}")
	public PoliceStationDTO updateStation(@PathVariable("stationId") int stationId,
			@RequestBody PoliceStationDTO stationDTO)
	{
		final PoliceStation policeStation= sConverter.converToStationEntity(stationDTO);
		return stationService.updateStationById(stationId, policeStation);
	}
	
	@DeleteMapping("/deleteStation/{stationId}")
	public ResponseEntity<String> deleteStationById(@PathVariable("stationId") int stationId)
	{
		stationService.deleteStationById(stationId);
		return new ResponseEntity<String>("Police Station details with id"+stationId+"deleted successfully",
				HttpStatus.OK);
	}
	
	@GetMapping("/getStationById{id}")
	public PoliceStationDTO getStationById(@PathVariable("id") int id)
	{
		return stationService.getStationById(id);
	}
	
	
	
}
