package com.kny.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kny.entity.Vehicle;
import com.kny.model.VehicleDTO;
import com.kny.service.VehicleService;
import com.kny.utils.VehicleConverter;

@RestController
public class VehicleController {
	
	@Autowired
	VehicleConverter vConverter;
	
	@Autowired
	VehicleService vehicleService;
	
	// build save vehicle details using REST API
	@PostMapping("/addVehicle")
	public VehicleDTO addVehicle(@Valid @RequestBody VehicleDTO vDto)
	{
		Vehicle vehicle = vConverter.converToVehicleEntity(vDto);
		return vehicleService.addVehicle(vehicle);
	}
	
	
	// build get vehicle details using vehicle no REST API
	@GetMapping("/findVehicle/{vehicleNo}")
	public VehicleDTO getVehicleDetailsByNo(@PathVariable("vehicleNo") String vehicleNo)
	{
		return vehicleService.getVehicleDetailsByNo(vehicleNo);
	}
	
	
	// build update vehicle details using id REST API
	@PutMapping("/updateVehicle/{vehicleId}")
	public VehicleDTO updateVehicleDetailsById(@PathVariable("vehicleId")int id,
			@RequestBody VehicleDTO vDto)
	{
		final Vehicle vehicle = vConverter.converToVehicleEntity(vDto);
		return vehicleService.updateVehicleById(id, vehicle);
	}

// build delete vehicle details using id REST API
	@DeleteMapping("/deleteVehicle/{vehicleId}")
	public ResponseEntity<String> deleteVehicleById(@PathVariable("vehicleId") int id)
	{
		vehicleService.deleteVehicleDetailsById(id);
		return new ResponseEntity<String>("Vehicle details with id "+id+" deleted successfully",
				HttpStatus.OK);
	}
	
	// build assign vehicle an Station
	@PostMapping("/assignVehicle/{vId}/{sId}")
	public VehicleDTO assignVehicleToStation(@PathVariable("vId") int vehicleId,
			@PathVariable("sId") int stationId)
	{
		return vehicleService.assignVehicleToStation(vehicleId, stationId);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}