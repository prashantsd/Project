package com.kny;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
//@SpringBootApplication(exclude= DataSourceAutoConfiguration.class)
public class KyvApplication {
	public static void main(String[] args) {
		SpringApplication.run(KyvApplication.class, args);
		System.out.println("Application Started Successfully.");
	}
}
