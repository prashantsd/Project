package com.kny.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleNoAlreadyExist extends RuntimeException{


	private static final long serialVersionUID = 1L;
	
	private String message;

	public VehicleNoAlreadyExist(String message) {
		super(message);
		this.message = message;
	}
	
	

}
