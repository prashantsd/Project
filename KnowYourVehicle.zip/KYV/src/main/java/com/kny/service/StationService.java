package com.kny.service;

import java.util.List;




import com.kny.entity.PoliceStation;
import com.kny.model.PoliceStationDTO;

public interface StationService {
	// this method is used to save the Station
	PoliceStationDTO saveStation(PoliceStation pStation);
	// this method is used to fetch all station
	List<PoliceStationDTO> getAllStations(); 
	// this method is used to update Station details using id
	PoliceStationDTO updateStationById(int stationId,PoliceStation policeStation);
	// this method is used to delete Station details using id
	void deleteStationById(int stationId);
	// this method is used to get station details using id
	PoliceStationDTO getStationById(int id);
	
	

	
}
