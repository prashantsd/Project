package com.kny.service;

import com.kny.entity.Vehicle;
import com.kny.model.VehicleDTO;

public interface VehicleService {
	
	// this method is used to add vehicle
	VehicleDTO addVehicle(Vehicle vehicle);
	// this method is used to find the vehicle using its no.
	VehicleDTO getVehicleDetailsByNo(String vehicleNo);
	// this method is used to update vehicle details using id
	VehicleDTO updateVehicleById(int id,Vehicle vehicle);
	// this method is used to delete vehicle details using id
	void deleteVehicleDetailsById(int id);
	// this method is used to assign an vehicle to station
	VehicleDTO assignVehicleToStation(int vehicleId,int stationId);
	
	
}
