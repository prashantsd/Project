package com.kny.entity;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.resource.beans.internal.FallbackBeanInstanceProducer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "Police_Station")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PoliceStation extends User{

		
	@Column(length = 20,nullable = false)
	private String stationName;
	
	@Column(length = 20,nullable = false)
	private String city;
	
	@Column(length = 40,nullable = false)
	private String address;
	
	@Column(unique = true,length = 20,nullable = false)
	private String contact;
	
	@Column(length = 6,nullable = false)
	private String pinCode;

	@OneToMany(cascade = CascadeType.ALL)
	private List<Vehicle> vehicles;

	
	
	
	
}
