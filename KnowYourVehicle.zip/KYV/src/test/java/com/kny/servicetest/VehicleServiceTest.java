package com.kny.servicetest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.kny.entity.Vehicle;
import com.kny.model.VehicleDTO;
import com.kny.repository.VehicleRepository;
import com.kny.service.VehicleService;
import com.kny.utils.VehicleConverter;

@SpringBootTest
class VehicleServiceTest {

	
	@MockBean
	VehicleRepository vRepository;
	
	@Autowired
	VehicleService vehicleService;
	
	@Autowired
	VehicleConverter converter;
	
	Vehicle vehicle;
	
	@BeforeEach
	void setUp() throws Exception {
		
		vehicle = Vehicle.builder().vehicleNo("MH20DL5454")
				.company("TATA")
				.vehicleType("Car")
				.address("Tilak Nagar kannad")
				.build();
				
	}
	
	@Test
	@DisplayName("Testing Save Vehicle details")
	void testSaveVehicle()
	{
		Mockito.when(vRepository.save(vehicle)).thenReturn(vehicle);
		assertEquals("MH20DL5454", vehicleService.addVehicle(vehicle).getVehicleNo());
	}
	


	

}
