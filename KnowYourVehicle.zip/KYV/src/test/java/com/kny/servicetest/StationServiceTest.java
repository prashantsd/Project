package com.kny.servicetest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.kny.entity.PoliceStation;
import com.kny.entity.Vehicle;
import com.kny.model.PoliceStationDTO;
import com.kny.repository.StationRepository;
import com.kny.repository.VehicleRepository;
import com.kny.service.StationService;
import com.kny.utils.StationConverter;

@SpringBootTest
class StationServiceTest {
	
	
	@MockBean
	StationRepository stationRepository;

	@Autowired
	StationConverter sConverter;
	
	@Autowired
	StationService stationService;
	
	
	PoliceStation station;
	
	@BeforeEach
	void setUp() throws Exception {
		
		station = PoliceStation.builder().stationName("Kannad Police Station")
				.city("Kannad")
				.address("Near Shivaji Statue ,Tahasil Road Kannad")
				.contact("7768867728")
				.pinCode("431103")
				.build();
		
	}
	
	
	// test method will test save Police Station method
	@Test
	@DisplayName("Testing Save Police station method")
	void testSaveStation()
	{
		Mockito.when(stationRepository.save(station)).thenReturn(station);
		assertEquals("Kannad", stationService.saveStation(station).getCity());
	}
	
	
	@Test
	@DisplayName("Testing get station details using id")
	void testgetStationById()
	{
		
		Optional<PoliceStation> opStation = Optional.of(station);
		Mockito.when(stationRepository.findById(station.getId())).thenReturn(opStation);
		
		PoliceStationDTO stationDTO = sConverter.converterToStationDTO(opStation.get());
		assertThat(stationService.getStationById(station.getId()).getStationName()).isEqualTo(stationDTO.getStationName());
	}
	
	
	// negative test case with Police Station PinCode
	@Test
	@DisplayName("Negative Test Case")
	void testNegativePicCode()
	{
		
		Optional<PoliceStation> opStation = Optional.of(station);
		Mockito.when(stationRepository.findById(station.getId())).thenReturn(opStation);
		
		PoliceStationDTO stationDTO = sConverter.converterToStationDTO(opStation.get());
		assertThat(stationService.getStationById(station.getId()).getPinCode())
		.isEqualTo("431104");
	}
	
	
	

	
	

	

}
